const express = require("express");
const app = express();
const https =require("https")
const bodyParser = require("body-parser")
app.use(bodyParser.urlencoded({extended:true}))
app.get("/",((req,res)=>{
res.sendFile(__dirname + "/index.html")
}))
app.post("/",((req,res)=>{
    const appKey = "cc69d37d9e5a4728b3263245231401";
    const cityName = req.body.cityName
    
      const url = "https://api.weatherapi.com/v1/current.json?key="+ appKey +"&q="+ cityName + "&aqi=no"

    https.get(url,((response)=>{ 
        response.on("data",function(data){
            const weatherData = JSON.parse(data);
            const temperature =weatherData.current.temp_c;
            const weather = weatherData.current.condition.text;
            const imageUrl = weatherData.current.condition.icon;
            res.write("<p>The weather currently is " + weather + "</p>")
            res.write("<h1>The Temperture of  " +  cityName +  " is " + temperature +" degree celsius</h1>" )
            res.write("<img src=" + imageUrl + ">");
            res.send();
         })
       }))
}))













app.listen(5500,(()=>{
    console.log("Server is running at port 5500")
}))